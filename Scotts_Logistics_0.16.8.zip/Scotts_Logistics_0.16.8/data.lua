--data.lua

require("prototypes.item.item")
require("prototypes.item.group")

require("prototypes.entity.entity")
require("prototypes.entity.entity_drone")
require("prototypes.entity.transport-belt-pictures")


require("prototypes.recipe.recipe")

require("prototypes.technology")

