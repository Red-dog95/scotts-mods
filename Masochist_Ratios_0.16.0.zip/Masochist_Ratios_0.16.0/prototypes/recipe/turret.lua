data:extend(
{
  {
    type = "recipe",
    name = "laser-turret",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"steel-plate", 19},
      {"electronic-circuit", 23},
      {"battery", 13}
    },
    result = "laser-turret"
  },
  {
    type = "recipe",
    name = "flamethrower-turret",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"steel-plate", 31},
      {"iron-gear-wheel", 13},
      {"pipe", 11},
      {"engine-unit", 5}
    },
    result = "flamethrower-turret"
  },
  {
    type = "recipe",
    name = "artillery-turret",
    enabled = false,
    energy_required = 40,
    ingredients =
    {
      {"steel-plate", 61},
      {"concrete", 61},
      {"iron-gear-wheel", 43},
      {"advanced-circuit", 19}
    },
    result = "artillery-turret"
  }
}
)
