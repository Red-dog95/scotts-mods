data:extend(
{
  {
    type = "recipe",
    name = "copper-plate",
    category = "smelting",
    energy_required = 7,
    ingredients = {{ "copper-ore", 3}},
    results = {{name = "copper-plate", amount = 2}}
  },
  {
    type = "recipe",
    name = "iron-plate",
    category = "smelting",
    energy_required = 7,
    ingredients = {{"iron-ore", 3}},
    results = {{name = "iron-plate", amount = 2}}
  },
  {
    type = "recipe",
    name = "stone-brick",
    category = "smelting",
    energy_required = 7,
    enabled = true,
    ingredients = {{"stone", 7}},
    results = {{ name ="stone-brick", amount = 3}}
  }
}
)
