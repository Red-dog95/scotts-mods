data:extend(
{
  {
    type = "recipe",
    name = "steel-plate",
    category = "smelting",
    normal =
    {
      enabled = false,
      energy_required = 17.5,
      ingredients = {{"iron-plate", 7}},
      result = "steel-plate",
	  result_count = 2
    },
    expensive =
    {
      enabled = false,
      energy_required = 35,
      ingredients = {{"iron-plate", 17}},
      result = "steel-plate",
	  result_count = 2
    }
  }
}
)
