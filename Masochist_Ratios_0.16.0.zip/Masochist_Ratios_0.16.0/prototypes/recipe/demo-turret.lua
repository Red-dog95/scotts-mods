data:extend(
{
  {
    type = "recipe",
    name = "gun-turret",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"iron-gear-wheel", 11},
      {"copper-plate", 13},
      {"iron-plate", 19}
    },
    result = "gun-turret"
  }
}
)
