data:extend(
{
  {
    type = "recipe",
    name = "speed-module",
    enabled = false,
    ingredients =
    {
      {"advanced-circuit", 3},
      {"electronic-circuit", 7}
    },
    energy_required = 13,
    result = "speed-module"
  },
  {
    type = "recipe",
    name = "speed-module-2",
    enabled = false,
    ingredients =
    {
      {"speed-module", 3},
      {"advanced-circuit", 7},
      {"processing-unit", 5}
    },
    energy_required = 29,
    result = "speed-module-2"
  },
  {
    type = "recipe",
    name = "speed-module-3",
    enabled = false,
    ingredients =
    {
      {"speed-module-2", 11},
      {"advanced-circuit", 13},
      {"processing-unit", 7}
    },
    energy_required = 59,
    result = "speed-module-3",
	result_count = 2
  },
  {
    type = "recipe",
    name = "productivity-module",
    enabled = false,
    ingredients =
    {
      {"advanced-circuit", 3},
      {"electronic-circuit", 7}
    },
    energy_required = 13,
    result = "productivity-module"
  },
  {
    type = "recipe",
    name = "productivity-module-2",
    enabled = false,
    ingredients =
    {
      {"productivity-module", 3},
      {"advanced-circuit", 7},
      {"processing-unit", 5}
    },
    energy_required = 31,
    result = "productivity-module-2"
  },
  {
    type = "recipe",
    name = "productivity-module-3",
    enabled = false,
    ingredients =
    {
      {"productivity-module-2", 11},
      {"advanced-circuit", 13},
      {"processing-unit", 7}
    },
    energy_required = 59,
    result = "productivity-module-3",
	result_count = 2
  },
  {
    type = "recipe",
    name = "effectivity-module",
    enabled = false,
    ingredients =
    {
      {"advanced-circuit", 3},
      {"electronic-circuit", 7}
    },
    energy_required = 15,
    result = "effectivity-module"
  },
  {
    type = "recipe",
    name = "effectivity-module-2",
    enabled = false,
    ingredients =
    {
      {"effectivity-module", 3},
      {"advanced-circuit", 7},
      {"processing-unit", 5}
    },
    energy_required = 30,
    result = "effectivity-module-2"
  },
  {
    type = "recipe",
    name = "effectivity-module-3",
    enabled = false,
    ingredients =
    {
      {"effectivity-module-2", 11},
      {"advanced-circuit", 13},
      {"processing-unit", 7}
    },
    energy_required = 59,
    result = "effectivity-module-3",
	result_count = 2
  }
}
)
