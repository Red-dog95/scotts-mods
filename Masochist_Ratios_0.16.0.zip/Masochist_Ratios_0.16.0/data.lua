--data.lua
require("prototypes.recipe.demo-furnace-recipe")
require("prototypes.recipe.demo-recipe")
require("prototypes.recipe.demo-turret")
require("prototypes.recipe.ammo")
require("prototypes.recipe.capsule")
require("prototypes.recipe.equipment")
require("prototypes.recipe.furnace-recipe")
require("prototypes.recipe.fluid-recipe")
require("prototypes.recipe.inserter")
require("prototypes.recipe.module")
require("prototypes.recipe.recipe")
require("prototypes.recipe.turret")

