--__Scotts_Logistics__/graphics/icons/tech/

data:extend(
{
	{
	type = "technology",
    name = "simple-flight",
    icon_size = 128,
    icon = "__Scotts_Logistics__/graphics/icons/tech/simple-flight.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "drone-frame"
      },
    },
	prerequisites = {"electronics"},
    unit =
    {
      count = 50,
      ingredients = {{"science-pack-1", 1}},
      time = 30
    },
    order = "a-bc-a"
	},
	
	
	{
		type = "technology",
		name = "simple-chemistry",
		icon_size = 128,
		icon = "__Scotts_Logistics__/graphics/icons/tech/simple-chemistry.png",
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "iron-battery"
		  },
		},
		prerequisites = {"electronics", "logistics"},
		unit =
		{
		  count = 50,
		  ingredients = {{"science-pack-1", 1}},
		  time = 30
		},
		order = "a-b-aa"
	},
	{
		type = "technology",
		name = "simple-logistic-system",
		icon_size = 128,
		icon = "__Scotts_Logistics__/graphics/icons/tech/simple-logistic-system.png",
		effects =
		{
			{
			type = "unlock-recipe",
			recipe = "construction-drone"
			},
			{
			type = "unlock-recipe",
			recipe = "logistic-drone-chest-passive-provider"
			},
			{
			type = "unlock-recipe",
			recipe = "logistic-drone-chest-storage"
			}
		},
		prerequisites = {"electronics", "logistics","simple-chemistry","simple-flight"},
		unit =
		{
		count = 100,
		ingredients = {{"science-pack-1", 1}},
		time = 30,
		},
		order = "a-c-aa"
	},
		{
			type = "technology",
			name = "steel-casting",
			icon_size = 128,
			icon = "__Scotts_Logistics__/graphics/icons/tech/steel-processing.png",
			effects = 
			{
				{
				type = "unlock-recipe",
				recipe = "steel-sheet"
				}
		
			},
		prerequisites = {"steel-processing"},
		unit = {
		count = 80,
		ingredients = {{"science-pack-1",1}},
		time = 30,
		},
		order = "a-b-b"
		},
			{
			type = "technology",
			name = "fluid-handling",
			icon_size = 128,
			icon = "__Scotts_Logistics__/graphics/icons/tech/fluid-handling.png",
			effects = 
			{
				{
				type = "unlock-recipe",
				recipe = "storage-tank"
				},
				{
				type = "unlock-recipe",
				recipe = "empty-barrel"
				},
				{
				type = "unlock-recipe",
				recipe = "steel-pipe"
				},
				{
				type = "unlock-recipe",
				recipe = "steel-pipe-to-ground"
				}
		
			},
		prerequisites = {"steel-casting","automation"},
		unit = {
		count = 100,
		ingredients = {{"science-pack-1",1}},
		time = 30,
		},
		order = "a-b-b"
		},
		
		{	type = "technology",
		name = "overclocking",
		icon_size = 128,
		icon = "__Scotts_Logistics__/graphics/icons/tech/overclocking.png",
		effects =
		{
			{
			type = "unlock-recipe",
			recipe = "overclocked-circuit"
			}
		},
		prerequisites = {"logistics-2","stack-inserter","advanced-electronics"},
		unit =
		{
		count = 100,
		ingredients = {{"science-pack-1", 1},{"science-pack-2", 2}},
		time = 60,
		},
		order = "a-c-aa"
	
		},
	{	type = "technology",
		name = "application-overclocking",
		icon_size = 128,
		icon = "__Scotts_Logistics__/graphics/icons/tech/overclocking.png",
		effects =
		{
			{
			type = "unlock-recipe",
			recipe = "overclocked-inserter"
			},
			{
			type = "unlock-recipe",
			recipe = "overclocked-transport-belt"
			},
			{
			type = "unlock-recipe",
			recipe = "overclocked-underground-belt"
			},
			{
			type = "unlock-recipe",
			recipe = "overclocked-splitter"
			},
			
		
		},
		prerequisites = {"overclocking"},
		unit =
		{
		count = 150,
		ingredients = {{"science-pack-1", 1},{"science-pack-2", 1}},
		time = 60,
		},
		order = "b-c-aa"
	
		},
		{
		type = "technology",
		name = "better-automation",
		icon_size = 128,
		icon = "__Scotts_Logistics__/graphics/icons/tech/automation.png",
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "overclocked-assembling-machine"
		  }
		 },
		prerequisites = {"automation-2", "overclocking", "electric-energy-distribution-1"},
		unit =
		{
	  count = 200,
		  ingredients = {{"science-pack-1", 1}, {"science-pack-2", 1}},
		  time = 60,
		},
		order = "e-a-a"
		},
		{
		type = "technology",
		name = "overclocked-material-processing",
		icon_size = 128,
		icon = "__Scotts_Logistics__/graphics/icons/tech/material-processing.png",
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "overclocked-furnace"
		  }
		},
		prerequisites = {"advanced-material-processing-2", "overclocking"},
		unit =
		{
	  count = 800,
		  ingredients = {{"science-pack-1", 2}, {"science-pack-2", 2}, {"science-pack-3",1}},
		  time = 45
		},
		order = "e-bc-a"
		},
		--Modified tech tree
		{
				type = "technology",
				name = "logistics",
				icon_size = 128,
				icon = "__base__/graphics/technology/logistics.png",
				effects =
				{
				  {
					type = "unlock-recipe",
					recipe = "primitive-underground-belt"
				  },
				  {
					type = "unlock-recipe",
					recipe = "transport-belt"
				  },
				  {
					type = "unlock-recipe",
					recipe = "primitive-splitter"
				  }
				},
				unit =
				{
				  count = 20,
				  ingredients = {{"science-pack-1", 1}},
				  time = 15
				},
				order = "a-f-a"
			  },
			  {
				type = "technology",
				name = "electronics",
				icon_size = 128,
				icon = "__base__/graphics/technology/electronics.png",
				effects =
				{
				  {
					type = "unlock-recipe",
					recipe = "fast-inserter"
				  },
				  {
					type = "unlock-recipe",
					recipe = "long-handed-inserter"
				  },
				},
				prerequisites = {"automation"},
				unit =
				{
				  count = 30,
				  ingredients = {{"science-pack-1", 1}},
				  time = 15
				},
				order = "a-d-a"
  },
			{type = "technology",
			name = "logistics-1-beta",
			icon_size = 128,
				icon = "__base__/graphics/technology/logistics.png",
				effects =
				{
				  {
					type = "unlock-recipe",
					recipe = "underground-belt"
				  },
				  {
					type = "unlock-recipe",
					recipe = "filter-inserter"
				  },
				  {
					type = "unlock-recipe",
					recipe = "splitter"
				  }
				},
				prerequisites = {"logistics","electronics"},
				unit =
				{
				  count = 40,
				  ingredients = {{"science-pack-1", 1}},
				  time = 15
				},
				order = "a-f-a"
			  },
			  {
		type = "technology",
		name = "automation",
		icon_size = 128,
		icon = "__base__/graphics/technology/automation.png",
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "assembling-machine-1"
		  },
		  {
			type = "unlock-recipe",
			recipe = "inserter"
		  }
		},
		unit =
		{
		  count = 10,
		  ingredients = {{"science-pack-1", 1}},
		  time = 10
		},
		order = "a-b-a"
  },
  

}
)