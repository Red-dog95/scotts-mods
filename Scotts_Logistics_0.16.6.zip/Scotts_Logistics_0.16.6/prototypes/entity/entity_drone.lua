-- __Scotts_Logistics__/graphics/entity/drones/construction-drone/
require("prototypes.colour")
tint_overclocked_inserter = {r=0.4,g=1,b=0.4}

tint_steel_sheet = {r=1,g=1,b=1}
tint_steel_pipe = {r=0.66,g=0.66,b=0.66}
tint_steel_sheet = {r=255, g=255, b=255}

--tint_drone_frame = {r=1,g=1,b=1,a=0.3}
data:extend(
{
	{--CONSTRUCTION DRONE   

   type = "construction-robot",
    name = "construction-drone",
    icon = "__Scotts_Logistics__/graphics/icons/construction-drone.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation", "placeable-off-grid", "not-on-map"},
    minable = {hardness = 0.1, mining_time = 0.1, result = "construction-drone"},
    resistances = { { type = "fire", percent = 85 } },
    max_health = 40,
    collision_box = {{0, 0}, {0, 0}},
    selection_box = {{-0.5, -1.5}, {0.5, -0.5}},
    max_payload_size = 1,
    speed = 0.03,
    transfer_distance = 0.3,
    max_energy = "1.5MJ",
    energy_per_tick = "0.065kJ",
    speed_multiplier_when_out_of_energy = 0.1,
    energy_per_move = "5.85kJ",
    min_to_charge = 0.35,
    max_to_charge = 0.95,
    working_light = {intensity = 0.5, size = 2, color = {r = 0.8, g = 0.8, b = 0.8}},
    idle =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/construction-robot.png",
      priority = "high",
      line_length = 16,
      width = 32,
      height = 36,
      frame_count = 1,
      shift = {0, -0.15625},
      direction_count = 16,
	  
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/hr-construction-robot.png",
        priority = "high",
        line_length = 16,
        width = 66,
        height = 76,
        frame_count = 1,
        shift = util.by_pixel(0,-4.5),
        direction_count = 16,
		tint = {r=0.760,g=0.07,b=0},
        scale = 0.5
      }
    },
    in_motion =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/construction-robot.png",
      priority = "high",
      line_length = 16,
      width = 32,
      height = 36,
      frame_count = 1,
      shift = {0, -0.15625},
      direction_count = 16,
	  tint = {r=0.760,g=0.07,b=0},
      y = 36,
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/hr-construction-robot.png",
        priority = "high",
        line_length = 16,
        width = 66,
        height = 76,
        frame_count = 1,
        shift = util.by_pixel(0, -4.5),
        direction_count = 16,
		tint = {r=0.760,g=0.07,b=0},
        y = 76,
        scale = 0.5
      }
    },
    shadow_idle =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/construction-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 50,
      height = 24,
      frame_count = 1,
      shift = {1.09375, 0.59375},
      direction_count = 16,
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/hr-construction-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 104,
        height = 49,
        frame_count = 1,
        shift = util.by_pixel(33.5, 18.75),
        direction_count = 16,
        scale = 0.5
      }
    },
    shadow_in_motion =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/construction-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 50,
      height = 24,
      frame_count = 1,
      shift = {1.09375, 0.59375},
      direction_count = 16,
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/hr-construction-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 104,
        height = 49,
        frame_count = 1,
        shift = util.by_pixel(33.5, 18.75),
        direction_count = 16,
        scale = 0.5
      }
    },
    working =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/construction-robot-working.png",
      priority = "high",
      line_length = 2,
      width = 28,
      height = 36,
      frame_count = 2,
      shift = {0, -0.15625},
      direction_count = 16,
	  tint = {r=0.760,g=0.07,b=0},
      animation_speed = 0.3,
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/hr-construction-robot-working.png",

        priority = "high",
        line_length = 2,
        width = 57,
        height = 74,
        frame_count = 2,
        shift = util.by_pixel(-0.25, -5),
        direction_count = 16,
		tint = {r=0.760,g=0.07,b=0},
        animation_speed = 0.3,
        scale = 0.5
      }
    },
    shadow_working =
    {
      stripes = util.multiplystripes(2,
      {
        {
          filename = "__Scotts_Logistics__/graphics/entity/drones/construction-drone/construction-robot-shadow.png",
          width_in_frames = 16,
          height_in_frames = 1
        }
      }),
      priority = "high",
      width = 50,
      height = 24,
      frame_count = 2,
      shift = {1.09375, 0.59375},
      direction_count = 16
    },
    smoke =
    {
      filename = "__base__/graphics/entity/smoke-construction/smoke-01.png",
      width = 39,
      height = 32,
      frame_count = 19,
      line_length = 19,
      shift = {0.078125, -0.15625},
      animation_speed = 0.3
    },
    sparks =
    {
      {
        filename = "__base__/graphics/entity/sparks/sparks-01.png",
        width = 39,
        height = 34,
        frame_count = 19,
        line_length = 19,
        shift = {-0.109375, 0.3125},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-02.png",
        width = 36,
        height = 32,
        frame_count = 19,
        line_length = 19,
        shift = {0.03125, 0.125},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-03.png",
        width = 42,
        height = 29,
        frame_count = 19,
        line_length = 19,
        shift = {-0.0625, 0.203125},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-04.png",
        width = 40,
        height = 35,
        frame_count = 19,
        line_length = 19,
        shift = {-0.0625, 0.234375},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-05.png",
        width = 39,
        height = 29,
        frame_count = 19,
        line_length = 19,
        shift = {-0.109375, 0.171875},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-06.png",
        width = 44,
        height = 36,
        frame_count = 19,
        line_length = 19,
        shift = {0.03125, 0.3125},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3
      }
    },
    working_sound = flying_robot_sounds(),
    cargo_centered = {0.0, 0.2},
    construction_vector = {0.30, 0.22}
  },
  
	{-- DRONE PORT
    type = "roboport",
    name = "drone-port",
	icon ="__Scotts_Logistics__/graphics/icons/drone-port.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "drone-port"},
    max_health = 250,
    corpse = "big-remnants",
    collision_box = {{-1.7, -1.7}, {1.7, 1.7}},
    selection_box = {{-2, -2}, {2, 2}},
    resistances =
    {
      {
        type = "fire",
        percent = 0
      },
      {
        type = "impact",
        percent = 30
      }
    },
    dying_explosion = "medium-explosion",
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      input_flow_limit = "3MW",
      buffer_capacity = "40MJ"
    },
    recharge_minimum = "20MJ",
    energy_usage = "35kW",
    -- per one charge slot
    charging_energy = "600kW",
    logistics_radius = 0,
    construction_radius = 40,
    charge_approach_distance = 3,
    robot_slots_count = 4,
    material_slots_count = 4,
    stationing_offset = {0, 0},
    charging_offsets =
    {
      {-1.5, -0.5}, {1.5, -0.5}, {1.5, 1.5}, {-1.5, 1.5}
    },
    base =
    {
      layers =
      {
        {
          filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/roboport-base.png",
          width = 143,
          height = 135,
		  
          shift = {0.5, 0.25},
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/hr-roboport-base.png",
            width = 228,
            height = 277,
			tint = {r=0.015,g=0.466,b=0.560},
            shift = util.by_pixel(2, 7.75),
            scale = 0.5
          }
        },
        {
          filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/roboport-shadow.png",
          
		  width = 147,
          height = 102,
          draw_as_shadow = true,
          shift = util.by_pixel(28.5, 19.25),
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/hr-roboport-shadow.png",
            width = 294,
            height = 201,
            draw_as_shadow = true,
            shift = util.by_pixel(28.5, 19.25),
            scale = 0.5
          }
        }
      }
    },
    base_patch =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/roboport-base-patch.png",
	  priority = "medium",
      width = 69,
      height = 50,
	  tint = {r=0.015,g=0.466,b=0.560},
      frame_count = 1,
      shift = {0.03125, 0.203125},
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/hr-roboport-base-patch.png",
		priority = "medium",
        width = 138,
        height = 100,
		tint = {r=0.015,g=0.466,b=0.560},
        frame_count = 1,
        shift = util.by_pixel(1.5, 5),
        scale = 0.5
      }
    },
    base_animation =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/roboport-base-animation.png",
      priority = "medium",
      width = 42,
      height = 31,
      frame_count = 8,
      animation_speed = 0.3,
      shift = {-0.5315, -1.9375},
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/hr-roboport-base-animation.png",
        priority = "medium",
        width = 83,
        height = 59,
        frame_count = 8,
        animation_speed = 0.3,
        shift = util.by_pixel(-17.75, -61.25),
        scale = 0.5
      }
    },
    door_animation_up =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/roboport-door-up.png",
      priority = "medium",
      width = 52,
      height = 20,
      frame_count = 16,
      shift = {0.015625, -0.890625},
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/hr-roboport-door-up.png",
        priority = "medium",
        width = 97,
        height = 38,
        frame_count = 16,
        shift = util.by_pixel(-0.25, -29.5),
        scale = 0.5
      }
    },
    door_animation_down =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/roboport-door-down.png",
      priority = "medium",
      width = 52,
      height = 22,
      frame_count = 16,
      shift = {0.015625, -0.234375},
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/hr-roboport-door-down.png",
        priority = "medium",
        width = 97,
        height = 41,
        frame_count = 16,
        shift = util.by_pixel(-0.25,-9.75),
        scale = 0.5
      }
    },
    recharging_animation =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/drone-port/roboport-recharging.png",
      priority = "high",
      width = 37,
      height = 35,
      frame_count = 16,
      scale = 1.5,
      animation_speed = 0.5
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__base__/sound/roboport-working.ogg", volume = 0.6 },
      max_sounds_per_type = 3,
      audible_distance_modifier = 0.5,
      probability = 1 / (5 * 60) -- average pause between the sound is 5 seconds
    },
    recharging_light = {intensity = 0.4, size = 5, color = {r = 1.0, g = 1.0, b = 1.0}},
    request_to_open_door_timeout = 15,
    spawn_and_station_height = -0.1,

    draw_logistic_radius_visualization = false,
    draw_construction_radius_visualization = true,

    open_door_trigger_effect =
    {
      {
        type = "play-sound",
        sound = { filename = "__base__/sound/roboport-door.ogg", volume = 0.75 }
      }
    },
    close_door_trigger_effect =
    {
      {
        type = "play-sound",
        sound = { filename = "__base__/sound/roboport-door.ogg", volume = 0.75 }
      }
    },

    circuit_wire_connection_point = circuit_connector_definitions["roboport"].points,
    circuit_connector_sprites = circuit_connector_definitions["roboport"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance,

    default_available_logistic_output_signal = {type = "virtual", name = "signal-X"},
    default_total_logistic_output_signal = {type = "virtual", name = "signal-Y"},
    default_available_construction_output_signal = {type = "virtual", name = "signal-Z"},
    default_total_construction_output_signal = {type = "virtual", name = "signal-T"}
  },
  
  
	{--drone passive provider
		type = "logistic-container",
		name = "logistic-drone-chest-passive-provider",
		icon = "__Scotts_Logistics__/graphics/icons/logistic-drone-chest-passive-provider.png",
		icon_size = 32,
		flags = {"placeable-player", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "logistic-drone-chest-passive-provider"},
		max_health = 100,
    corpse = "small-remnants",
    collision_box = {{-0.35, -0.35}, {0.35, 0.35}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    resistances =
    {
      {
        type = "fire",
        percent = 90
      },
      {
        type = "impact",
        percent = 60
      }
    },
    fast_replaceable_group = "container",
    inventory_size = 16,
    logistic_mode = "passive-provider",
    open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
    close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    picture =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/logistic-chest-passive-provider.png",
      priority = "extra-high",
      width = 38,
      height = 32,
      shift = {0.09375, 0}
    },
    circuit_wire_connection_point = circuit_connector_definitions["chest"].points,
    circuit_connector_sprites = circuit_connector_definitions["chest"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  
	},
 
	{--drone storage
		type = "logistic-container",
		name = "logistic-drone-chest-storage",
		icon = "__Scotts_Logistics__/graphics/icons/logistic-drone-chest-storage.png",
		icon_size = 32,
		flags = {"placeable-player", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "logistic-drone-chest-storage"},
		 max_health = 100,
    logistic_slots_count = 1,
    corpse = "small-remnants",
    collision_box = {{-0.35, -0.35}, {0.35, 0.35}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    resistances =
    {
      {
        type = "fire",
        percent = 90
      },
      {
        type = "impact",
        percent = 60
      }
    },
    fast_replaceable_group = "container",
    inventory_size = 16,
    logistic_mode = "storage",
    open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
    close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    picture =
    {
      filename = "__Scotts_Logistics__/graphics/entity/drones/logistic-chest-storage.png",
      priority = "extra-high",
      width = 38,
      height = 32,
      shift = {0.09375, 0}
    },
    circuit_wire_connection_point = circuit_connector_definitions["chest"].points,
    circuit_connector_sprites = circuit_connector_definitions["chest"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
 
 } 
)