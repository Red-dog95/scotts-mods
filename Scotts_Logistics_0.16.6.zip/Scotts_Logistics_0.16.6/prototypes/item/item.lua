--item lsit.lua
--__Scotts_Logistics__/graphics/icons
-- Each item in the game needs a listing here: this is what appears in the inventory and crafting menu and on the floor
require("prototypes.colour")

tint_overclocked_inserter = {r=0.4,g=1,b=0.4}

tint_steel_sheet = {r=1,g=1,b=1}

tint_steel_pipe = {r=0.66,g=0.66,b=0.66}
tint_steel_sheet = {r=255, g=255, b=255}

data:extend(
{
	{
		type = "item",
		name = "wooden-inserter",
		icon = "__Scotts_Logistics__/graphics/icons/wooden-inserter.png",
		order = "a[wooden-inserter]-b[items]",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "inserter",
		place_result = "wooden-inserter",
		stack_size = 50
	},
	{
		type = "item",
		name = "overclocked-inserter",
		icons = {
		{
			icon = "__Scotts_Logistics__/graphics/icons/overclocked-inserter.png", 
			tint = tint_overclocked_inserter,
			icon_size = 32
			}
		},
		order = "a[items]-d[overclocked-inserter]-e[stack-inserter]",
		flags = {"goes-to-quickbar"},
		subgroup = "inserter",
		place_result = "overclocked-inserter",
		stack_size = 50
	},
	{
		type = "item",
		name = "construction-drone",
		icon = "__Scotts_Logistics__/graphics/icons/construction-drone.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "logistic-network",
		order = "a[robot]-a[construction-drone]",
		place_result = "construction-drone",
		tint = {r=0.760,g=0.07,b=0},
		stack_size = 50
	},
	{	
		type = "item",
		name = "drone-frame",
		icon = "__Scotts_Logistics__/graphics/icons/drone-frame.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "intermediate-product",
		order = "a1[drone-frame]",
		stack_size = 50

	},
	{
		type = "item",
		name = "iron-battery",
		icon = "__Scotts_Logistics__/graphics/icons/iron-battery.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "raw-material",
		order = "gz[iron-battery]",
		stack_size = 200
	},
	{
		type = "item",
		name = "drone-port",
		icon = "__Scotts_Logistics__/graphics/icons/drone-port.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "logistic-network",
		order = "aa[drone-port]",
		place_result = "drone-port",
		stack_size = 5
	},
		
		{
		type = "item",
		name = "logistic-drone-chest-storage",
		icon = "__Scotts_Logistics__/graphics/icons/logistic-drone-chest-storage.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "logistic-network",
		order = "b[storage]-aa[logistic-drone-chest-storage]",
		place_result = "logistic-drone-chest-storage",
		stack_size = 50
	},
	   {
		type = "item",
		name = "logistic-drone-chest-passive-provider",
		icon= "__Scotts_Logistics__/graphics/icons/logistic-drone-chest-passive-provider.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "logistic-network",
		order = "b[storage]-ab[logistic-drone-chest-passive-provider]",
		place_result = "logistic-drone-chest-passive-provider",
		stack_size = 50
		},
		
		{
		type = "item",
		name = "overclocked-circuit",
		icon = "__Scotts_Logistics__/graphics/icons/overclocked-circuit.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "intermediate-product",
		order = "a[electronic-ciruit]-c[overclocked-circuit]",
		stack_size = 200
		},
		{
		type = "item",
		name = "steel-sheet",
		icons = {{icon = "__Scotts_Logistics__/graphics/icons/steel-sheet.png", tint = tint_steel_sheet}},
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "intermediate-product",
		order = "a[steel-plate]-a[steel-sheet]",
		stack_size = 200
		},
		{
		type = "item",
		name = "overclocked-transport-belt",
		icon = "__Scotts_Logistics__/graphics/icons/overclocked-transport-belt.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "belt",
		order = "a[transport-belt]-c[overclocked-transport-belt]",
		place_result = "overclocked-transport-belt",
		stack_size = 100
		},
		{
		type = "item",
		name = "overclocked-underground-belt",
		icon = "__Scotts_Logistics__/graphics/icons/overclocked-underground-belt.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "belt",
		order = "b[underground-belt]-b[fast-underground-belt]-ba[overclocked-underground-belt]",
		place_result = "overclocked-underground-belt",
		stack_size = 50
	  },
			{
		type = "item",
		name = "overclocked-splitter",
		icon = "__Scotts_Logistics__/graphics/icons/overclocked-splitter.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "belt",
		order = "c[splitter]-b[fast-splitter]-ba[overclocked-splitter]",
		place_result = "overclocked-splitter",
		stack_size = 50
	  },
	  {
		type = "item",
		name = "overclocked-furnace",
		icon = "__Scotts_Logistics__/graphics/icons/overclocked-furnace.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "smelting-machine",
		order = "d[electric-furnace]",
		place_result = "overclocked-furnace",
		stack_size = 50
	  },
	  {
		type = "item",
		name = "overclocked-assembling-machine",
		icon= "__Scotts_Logistics__/graphics/icons/overclocked-assembling-machine.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "production-machine",
		order = "bg[overclocked-assembling-machine]-cg[assembling-machine-3]",
		place_result = "overclocked-assembling-machine",
		stack_size = 50
	  },
	  
	  {
		type = "item",
		name = "steel-pipe",
		icons = {{icon= "__base__/graphics/icons/pipe.png", tint = tint_steel_pipe}},
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "energy-pipe-distribution",
		order = "a[pipe-to-ground]-b[steel-pipe]",
		place_result = "steel-pipe",
		stack_size = 100
		},
		
		{
		type = "item",
		name = "steel-pipe-to-ground",
		icons = {{icon= "__base__/graphics/icons/pipe-to-ground.png", tint = tint_steel_pipe}},
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "energy-pipe-distribution",
		order = "a[pipe-to-ground]-c[steel-pipe-to-ground]",
		place_result = "steel-pipe-to-ground",
		stack_size = 500
		},
		 {
    type = "item",
    name = "storage-tank",
    icon = "__base__/graphics/icons/storage-tank.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "storage",
    order = "b[fluid]-a[storage-tank]",
    place_result = "storage-tank",
    stack_size = 50
  },
		{
    type = "item",
    name = "empty-barrel",
    icon = "__base__/graphics/icons/fluid/barreling/empty-barrel.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[empty-barrel]",
    stack_size = 10
  },
  {
		type = "item",
		name = "primitive-transport-belt",
		icon = "__Scotts_Logistics__/graphics/icons/primitive-transport-belt.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "belt",
		order = "b[transport-belt]-a[primitive-transport-belt]",
		place_result = "primitive-transport-belt",
		stack_size = 100
		},
		{
		type = "item",
		name = "primitive-underground-belt",
		icon = "__Scotts_Logistics__/graphics/icons/primitive-underground-belt.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "belt",
		order = "a[primitive-underground-belt], b[underground-belt]-",
		place_result = "primitive-underground-belt",
		stack_size = 50
	  },
			{
		type = "item",
		name = "primitive-splitter",
		icon = "__Scotts_Logistics__/graphics/icons/primitive-splitter.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "belt",
		order = "a[primitive-splitter], b[splitter]",
		place_result = "primitive-splitter",
		stack_size = 50
	  },
}	
)

