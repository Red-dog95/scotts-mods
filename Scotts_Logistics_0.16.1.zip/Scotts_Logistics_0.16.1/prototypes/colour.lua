--colour

tint_drone = {r=0.760,g=0.4,b=0.760}

tint_drone_port = {r=0.031,g=0.741,b=0.886}

tint_overclocked_inserter = {r=0.4,g=1,b=0.4}

tint_log_storage = {r=0.737, g=0.988, b=0.474}

tint_log_pass = {r=0.988, g=0.474, b=0.796}

tint_overclocked_furnace = {r=0.4, g=1, b=0.4}

tint_steel_sheet = {r=1,g=1,b=1}

tint_overclocked_assembling_machine = {r=0.325, g=0.874, b=0.768} 

tint_steel_sheet = {r=100, g=100, b=100}

tint_steel_pipe = {r=0.4,g=0.4,b=0.4}