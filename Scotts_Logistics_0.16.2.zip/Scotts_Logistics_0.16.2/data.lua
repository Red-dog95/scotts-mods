--data.lua

require("prototypes.item.item")

--require("prototypes.demo-item")
require("prototypes.entity.entity")
require("prototypes.entity.entity_drone")


require("prototypes.recipe.recipe")

require("prototypes.technology")
--require("prototypes.entity.control")

require("prototypes.entity.transport-belt-pictures")